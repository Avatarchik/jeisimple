﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PaysWrapper
{
	public List<int> pays;
	public List<bool> anticipate;
}